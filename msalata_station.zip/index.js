import express from 'express';
import mysql from 'mysql2/promise';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json());

// --- 1. إعدادات الاتصال بقاعدة بيانات Aiven ---
const dbConfig = {
    host: 'mysql-28d492e5-sajaboksande-bbbb.a.aivencloud.com',
    port: 21435,
    user: 'avnadmin',
    password: 'AVNS_Ciqp9f7t1WJ9xQBIfw-', // ⚠️ ضع كلمة مرور Aiven الحقيقية هنا بين العلامتين
    database: 'defaultdb',
    ssl: { rejectUnauthorized: false }
};

// --- 2. محرك تنفيذ الاستعلامات ---
const executeQuery = async (sql, params) => {
    let conn;
    try {
        conn = await mysql.createConnection(dbConfig);
        const [results] = await conn.execute(sql, params);
        return results;
    } catch (error) {
        console.error("خطأ تقني:", error);
        throw error;
    } finally {
        if (conn) await conn.end();
    }
};

// --- 3. وظيفة إنشاء الجداول تلقائياً (الرادار الذكي) ---
const initDatabase = async () => {
    const queries = [
        `CREATE TABLE IF NOT EXISTS drivers (
            id INT AUTO_INCREMENT PRIMARY KEY,
            driver_name VARCHAR(100),
            phone VARCHAR(20),
            car_type VARCHAR(50),
            plate_number VARCHAR(20),
            password VARCHAR(50),
            status VARCHAR(20) DEFAULT 'غير نشط'
        )`,
        `CREATE TABLE IF NOT EXISTS locations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            location_name VARCHAR(100),
            location_type VARCHAR(50),
            price DECIMAL(10,2)
        )`,
        `CREATE TABLE IF NOT EXISTS trips (
            id INT AUTO_INCREMENT PRIMARY KEY,
            passenger_name VARCHAR(100),
            passenger_phone VARCHAR(20),
            destination VARCHAR(100),
            driver_name VARCHAR(100),
            price DECIMAL(10,2),
            arrival_time INT,
            rating INT DEFAULT 0,
            status VARCHAR(20) DEFAULT 'Pending'
        )`
    ];

    for (let sql of queries) {
        await executeQuery(sql);
    }
    console.log("✅ تم تجهيز جداول مسلاتة في السحابة بنجاح!");
};

// تشغيل التهيئة عند بدء السيرفر
initDatabase().catch(err => console.error("فشل في تهيئة القاعدة:", err));

// --- 4. مسارات الـ API (المدير، السائق، الراكب) ---

app.post('/api/drivers', async (req, res) => {
    const { name, phone, car, plate, pass } = req.body;
    await executeQuery('INSERT INTO drivers (driver_name, phone, car_type, plate_number, password, status) VALUES (?,?,?,?,?,"غير نشط")', [name, phone, car, plate, pass]);
    res.json({ success: true });
});

app.post('/api/locations', async (req, res) => {
    const { name, type, price } = req.body;
    await executeQuery('INSERT INTO locations (location_name, location_type, price) VALUES (?,?,?)', [name, type, price]);
    res.json({ success: true });
});

app.get('/api/admin/stats', async (req, res) => {
    const rows = await executeQuery('SELECT driver_name, AVG(rating) as avg_stars, COUNT(id) as total_trips FROM trips WHERE rating > 0 GROUP BY driver_name ORDER BY avg_stars DESC');
    res.json(rows);
});

app.post('/api/driver/login', async (req, res) => {
    const { phone, pass } = req.body;
    const rows = await executeQuery('SELECT * FROM drivers WHERE phone = ? AND password = ?', [phone, pass]);
    if (rows.length > 0) {
        await executeQuery('UPDATE drivers SET status = "نشط" WHERE id = ?', [rows[0].id]);
        res.json({ success: true, driver: rows[0] });
    } else res.status(401).json({ message: "خطأ في البيانات" });
});

app.post('/api/trips', async (req, res) => {
    const { passenger_name, passenger_phone, destination, driver_name, price } = req.body;
    const result = await executeQuery('INSERT INTO trips (passenger_name, passenger_phone, destination, driver_name, price, status) VALUES (?,?,?,?,?,"Pending")', [passenger_name, passenger_phone, destination, driver_name, price]);
    res.json({ success: true, tripId: result.insertId });
});

app.patch('/api/trips/:id/accept', async (req, res) => {
    const { driver_id, arrival_time } = req.body;
    await executeQuery('UPDATE trips SET status = "Accepted", arrival_time = ? WHERE id = ?', [arrival_time, req.params.id]);
    await executeQuery('UPDATE drivers SET status = "غير متاح" WHERE id = ?', [driver_id]);
    res.json({ success: true });
});

app.patch('/api/trips/:id/rate', async (req, res) => {
    await executeQuery('UPDATE trips SET rating = ?, status = "Completed" WHERE id = ?', [req.body.rating, req.params.id]);
    const trip = await executeQuery('SELECT driver_name FROM trips WHERE id = ?', [req.params.id]);
    if (trip.length > 0) await executeQuery('UPDATE drivers SET status = "نشط" WHERE driver_name = ?', [trip[0].driver_name]);
    res.json({ success: true });
});

app.get('/api/drivers', async (req, res) => res.json(await executeQuery('SELECT * FROM drivers')));
app.get('/api/locations', async (req, res) => res.json(await executeQuery('SELECT * FROM locations')));
app.get('/api/trips', async (req, res) => res.json(await executeQuery('SELECT * FROM trips ORDER BY id DESC')));
app.get('/api/trips/:id', async (req, res) => {
    const rows = await executeQuery('SELECT t.*, d.car_type, d.plate_number FROM trips t LEFT JOIN drivers d ON t.driver_name = d.driver_name WHERE t.id = ?', [req.params.id]);
    res.json(rows[0]);
});

// --- 5. التشغيل النهائي ---
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 TX&M Server started on port ${PORT}`));